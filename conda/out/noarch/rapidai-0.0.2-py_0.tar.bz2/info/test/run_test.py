print("import: 'rapidai'")
import rapidai

